const Analytics = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Аналитика и цены</h1>
    </div>
  );
};

export default Analytics;
