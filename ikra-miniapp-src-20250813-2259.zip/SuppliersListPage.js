export default function SuppliersListPage() {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="text-lg font-semibold mb-2">РЎРїРёСЃРѕРє РїРѕСЃС‚Р°РІС‰РёРєРѕРІ</div>
      <div className="opacity-70">
        Р—РґРµСЃСЊ РїРѕР·Р¶Рµ РїРѕСЏРІРёС‚СЃСЏ С‚Р°Р±Р»РёС†Р°. РџРѕРєР° Р·Р°РіР»СѓС€РєР°.
      </div>
    </div>
  );
}
